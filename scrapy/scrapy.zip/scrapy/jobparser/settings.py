SPIDER_MODULES = ['jobparser.spiders']
NEWSPIDER_MODULE = 'jobparser.spiders'
BOT_NAME = 'job_parser'
USER_AGENT = 'Mozilla/92.0'
ROBOTSTXT_OBEY = False
LOG_ENABLED = False
LOG_LEVEL = 'DEBUG'  #INFO ERROR
LOG_FILE = 'log.txt'
